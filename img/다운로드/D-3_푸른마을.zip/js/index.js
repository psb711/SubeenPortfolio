// nav
$('.main_menu>li').hover(function(){
    $('.sub_menu').stop().fadeIn();
},function(){
    $('.sub_menu').stop().fadeOut();
});

//slider
let i=0;

function slide(){
i++;
if (i > $('.slide li:last').index()){
i=0;
}
$('.slide li').eq(i).stop().fadeIn('slow');
$('.slide li').eq(i-1).stop().fadeOut();
}

setInterval(slide,3000);

//tab menu
$('.tab li').click(function(){
    index = $(this).index();

    $('.tab_sub').eq(index).show().siblings().hide();
    $(this).addClass("active").siblings().removeClass("active");
});

//popup
$('table tr:first').click(function(){
    $('.popWrap').stop().fadeIn();    
});

$('.close').click(function(){
    $('.popWrap').stop().fadeOut(); 
});