let friend_name11 = "dooly";
var friend_name2 = "ddochi";
const friend_name33 = "dauner";
