export let friend_name1 = "둘리";
export var friend_name2 = "또치";
export const friend_name3 = "도우너";


