import {coffee as x,getCoffee as y} from "./moduleC1.js";

console.log(x);
console.log(y());
