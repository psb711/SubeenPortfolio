export let name = "Americano";

let coffee = {
	getName:function(){
		return name
	},
	setName:function(newName){
		name = newName
	}
};

export default coffee
