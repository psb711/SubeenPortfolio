//export default는 이름바꿔서 가능
//export된 것은 {} 안에 이름 바꾸면 안됨
import unico, {name} from "./moduleG1.js";

console.log(name);
console.log(unico.getName());

c.setName("Espresso");
console.log(unico.getName());
