import * as myCoffee from "./moduleC1.js";

console.log(myCoffee.coffee);
console.log(myCoffee.getCoffee());
myCoffee.setCoffee("Latte");
console.log(myCoffee.getCoffee());
