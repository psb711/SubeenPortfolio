let friend_name1 = "dooly";
var friend_name2 = "ddochi";
const friend_name3 = "dauner";

export {friend_name1, friend_name2, friend_name3};
