import coffee from "./moduleF1.js";

console.log(coffee.getName());

coffee.setName("Cappuccino");
console.log(coffee.getName());

console.log("------------------------");

import unico from "./moduleF1.js";

console.log(unico.getName());

unico.setName("Cappuccino");
console.log(unico.getName());
