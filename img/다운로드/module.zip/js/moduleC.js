import {coffee,getCoffee} from "./moduleC1.js";

console.log(coffee);
console.log(getCoffee());
// console.log(setCoffee("Latte"));
